document.addEventListener("DOMContentLoaded", function () {
    // Get references to the input elements and buttons
    const fileInput = document.getElementById("fileInput");
    const passwordInput = document.getElementById("passwordInput");
    const zipButton = document.getElementById("zipButton");
    const downloadLink = document.getElementById("downloadLink");

    // Add an event listener to the zipButton
    zipButton.addEventListener("click", function () {
        // Create a FormData object to send the files and password to the server
        const formData = new FormData();
        for (let i = 0; i < fileInput.files.length; i++) {
            formData.append("files", fileInput.files[i]);
        }
        formData.append("password", passwordInput.value);

        // Send a POST request to the server to zip the files
        fetch("/store", {
            method: "POST",
            body: formData,
        })
        .then(response => response.blob())
        .then(blob => {
            // Create a URL for the blob data
            const blobUrl = window.URL.createObjectURL(blob);

            // Set the download link href and display it
            downloadLink.href = blobUrl;
            downloadLink.style.display = "block";
        })
        .catch(error => {
            console.error("Error zipping files:", error);
        });
    });
});
