from flask import Flask, render_template, request, send_file, send_from_directory
import os
import zipfile
from io import BytesIO

app = Flask(__name__, static_url_path='/static', static_folder='static')

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Define the directory to be listed
LIST_DIRECTORY = 'old_archive_2022'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/store', methods=['POST'])
def store_files():
    uploaded_files = request.files.getlist('files')
    password = request.form.get('password')  # Get the password from the form

    if uploaded_files:
        zip_filename = 'stored_files.zip'
        zip_buffer = BytesIO()

        # Create a password-protected zip file using the zipfile module
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Set a password
            zf.setpassword(password.encode())

            for uploaded_file in uploaded_files:
                filename = uploaded_file.filename
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                uploaded_file.save(file_path)
                zf.write(file_path, os.path.basename(file_path))

        zip_buffer.seek(0)
        return send_file(
            zip_buffer,
            as_attachment=True,
            download_name=zip_filename,
            mimetype='application/zip'
        )

    return "Files are required."

@app.route('/old_archive_2022')
def list_directory():
    directory_path = os.path.join(app.root_path, LIST_DIRECTORY)
    files_and_folders = os.listdir(directory_path)
    return render_template('directory_listing.html', files_and_folders=files_and_folders)

@app.route('/old_archive_2022/<filename>')
def download_file(filename):
    directory_path = os.path.join(app.root_path, LIST_DIRECTORY)
    return send_from_directory(directory_path, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
